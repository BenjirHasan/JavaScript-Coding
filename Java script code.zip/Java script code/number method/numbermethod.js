//TYPE 1
var num = 20;
console.log(typeof(num)) ;

//TYPE 2
var num = "20.5";
num = parseFloat(num); //for float number

console.log(typeof(num));

//TYPE 3
var num = 2.5678;

console.log(number.toFixed(2)); //how many number should display after point
console.log(number.toPrecision(3));  // how many number should display overall
